import 'package:habit_tracker/data/database/app_database.dart';
import 'package:habit_tracker/data/models/category.dart';
import 'package:sqflite/sqflite.dart';

class CategoryRepository {
  Future<List<Category>> getAllCategories() async {
    final db = await AppDatabase().database;
    final List<Map<String, dynamic>> maps = await db.query('categories');
    return maps.map((e) => Category.fromMap(e)).toList();
  }

  Future<int> insertCategory(Category category) async {
    final db = await AppDatabase().database;
    return await db.insert('categories', category.toMap());
  }

  Future<void> deleteCategory(int id) async {
    final db = await AppDatabase().database;
    await db.delete('categories', where: 'id = ?', whereArgs: [id]);
  }
}