import 'package:habit_tracker/data/database/app_database.dart';
import 'package:habit_tracker/data/models/habit.dart';
import 'package:habit_tracker/data/models/habit_log.dart';
import 'package:sqflite/sqflite.dart';

class HabitRepository {
  Future<List<Habit>> getAllHabits() async {
    final db = await AppDatabase().database;
    final List<Map<String, dynamic>> maps = await db.query('habits', orderBy: 'created_at DESC');
    return maps.map((e) => Habit.fromMap(e)).toList();
  }

  Future<int> insertHabit(Habit habit) async {
    final db = await AppDatabase().database;
    return await db.insert('habits', habit.toMap());
  }

  Future<void> updateHabit(Habit habit) async {
    final db = await AppDatabase().database;
    await db.update(
      'habits',
      habit.toMap(),
      where: 'id = ?',
      whereArgs: [habit.id],
    );
  }

  Future<void> deleteHabit(int id) async {
    final db = await AppDatabase().database;
    await db.delete('habits', where: 'id = ?', whereArgs: [id]);
  }

  // Logs
  Future<List<HabitLog>> getLogsForHabit(int habitId) async {
    final db = await AppDatabase().database;
    final List<Map<String, dynamic>> maps = await db.query(
      'habit_logs',
      where: 'habit_id = ?',
      whereArgs: [habitId],
      orderBy: 'date DESC',
    );
    return maps.map((e) => HabitLog.fromMap(e)).toList();
  }

  Future<void> upsertLog(HabitLog log) async {
    final db = await AppDatabase().database;
    await db.insert(
      'habit_logs',
      log.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }
}