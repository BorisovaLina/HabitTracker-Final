import 'package:intl/intl.dart';

class HabitLog {
  int? id;
  int habitId;
  DateTime date; // день выполнения (без времени)
  bool completed;
  String? value; // если не бинарное — например, "8500"
  String? note; // комментарий: "не хватило времени"

  HabitLog({
    this.id,
    required this.habitId,
    required this.date,
    this.completed = true,
    this.value,
    this.note,
  });

  String get formattedDate => DateFormat('yyyy-MM-dd').format(date);

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'habit_id': habitId,
      'date': formattedDate,
      'completed': completed ? 1 : 0,
      'value': value,
      'note': note,
    };
  }

  factory HabitLog.fromMap(Map<String, dynamic> map) {
    return HabitLog(
      id: map['id'],
      habitId: map['habit_id'],
      date: DateTime.parse(map['date']),
      completed: (map['completed'] as int?) == 1,
      value: map['value'],
      note: map['note'],
    );
  }

  @override
  String toString() {
    return 'HabitLog(habitId: $habitId, date: $date, completed: $completed)';
  }
}