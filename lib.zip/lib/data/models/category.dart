import 'package:flutter/material.dart';

class Category {
  final int? id;
  final String name;
  final Color color;

  Category({
    this.id,
    required this.name,
    required this.color,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'color_value': color.value,
    };
  }

  factory Category.fromMap(Map<String, dynamic> map) {
    return Category(
      id: map['id'],
      name: map['name'],
      color: Color(map['color_value'] as int),
    );
  }

  @override
  String toString() {
    return 'Category(id: $id, name: $name, color: $color)';
  }
}