import 'package:flutter/material.dart';

enum FrequencyType { daily, weekdays, weekends, custom }

class Habit {
  int? id;
  String title;
  String? description;
  FrequencyType frequencyType;
  List<int> customDays;
  bool isBinary;
  String? goalValue;
  String? unit;
  int difficulty;
  bool completedToday;
  DateTime createdAt;

  Habit({
    this.id,
    required this.title,
    this.description,
    this.frequencyType = FrequencyType.daily,
    this.customDays = const [],
    this.isBinary = true,
    this.goalValue,
    this.unit,
    this.difficulty = 1,
    this.completedToday = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  String get frequencyLabel {
    switch (frequencyType) {
      case FrequencyType.daily: return 'Ежедневно';
      case FrequencyType.weekdays: return 'Будни';
      case FrequencyType.weekends: return 'Выходные';
      case FrequencyType.custom: return 'Конкретные дни';
    }
  }

  String get goalLabel => goalValue != null ? '$goalValue ${unit ?? ''}' : '';

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'frequency_type': frequencyType.index,
      'custom_days': customDays.join(','),
      'is_binary': isBinary ? 1 : 0,
      'goal_value': goalValue,
      'unit': unit,
      'difficulty': difficulty,
      'completed_today': completedToday ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Habit.fromMap(Map<String, dynamic> map) {
    final customDaysStr = map['custom_days'] as String?;
    final customDays = customDaysStr?.split(',').map((e) => int.parse(e)).toList() ?? [];
    return Habit(
      id: map['id'],
      title: map['title'],
      description: map['description'],
      frequencyType: FrequencyType.values[map['frequency_type'] ?? 0],
      customDays: customDays,
      isBinary: (map['is_binary'] as int?) == 1,
      goalValue: map['goal_value'],
      unit: map['unit'],
      difficulty: map['difficulty'] ?? 1,
      completedToday: (map['completed_today'] as int?) == 1,
      createdAt: DateTime.parse(map['created_at']),
    );
  }
}