import 'package:flutter/material.dart';
import 'package:habit_tracker/data/database/app_database.dart';
import 'package:habit_tracker/data/models/habit.dart';
import 'package:sqflite/sqflite.dart';

class HabitProvider extends ChangeNotifier {
  final AppDatabase _db = AppDatabase();
  List<Habit> _habits = [];

  bool _isLoading = false;
  bool get isLoading => _isLoading;
  List<Habit> get habits => _habits;

  Future<void> loadAll() async {
    if (_isLoading) return;
    _isLoading = true;
    notifyListeners();

    try {
      final db = await _db.database;
      final List<Map<String, dynamic>> maps = await db.query('habits');
      _habits = maps.map((e) => Habit.fromMap(e)).toList();
      notifyListeners();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addHabit(Habit habit) async {
    final db = await _db.database;
    final id = await db.insert('habits', habit.toMap());
    habit.id = id;
    _habits.add(habit);
    notifyListeners();
  }

  Future<void> toggleCompletion(int id) async {
    final habit = _habits.firstWhere((h) => h.id == id);
    habit.completedToday = !habit.completedToday;
    final db = await _db.database;
    await db.update(
      'habits',
      habit.toMap(),
      where: 'id = ?',
      whereArgs: [id],
    );
    notifyListeners();
  }
}