import 'package:flutter/material.dart';
import 'package:collection/collection.dart'; // для firstWhereOrNull
import 'package:habit_tracker/data/models/category.dart';
import 'package:habit_tracker/data/repositories/category_repository.dart';

class CategoryProvider extends ChangeNotifier {
  final CategoryRepository _repository = CategoryRepository();
  List<Category> _categories = [];

  List<Category> get categories => _categories;

  Future<void> loadAll() async {
    _categories = await _repository.getAllCategories();
    notifyListeners();
  }

  Future<void> addCategory(Category category) async {
    final id = await _repository.insertCategory(category);
    final newCat = Category(id: id, name: category.name, color: category.color);
    _categories.add(newCat);
    notifyListeners();
  }

  Future<void> deleteCategory(int id) async {
    await _repository.deleteCategory(id);
    _categories.removeWhere((c) => c.id == id);
    notifyListeners();
  }

  Category? findById(int? id) {
    return _categories.firstWhereOrNull((c) => c.id == id);
  }
}