import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthProvider extends ChangeNotifier {
  bool _isAuthenticated = false;
  bool get isAuthenticated => _isAuthenticated;

  Future<void> initializeAuth() async {
    final prefs = await SharedPreferences.getInstance();
    _isAuthenticated = prefs.getBool('is_authenticated') ?? false;
    notifyListeners();
  }

  Future<void> login(String login, String password) async {
    if (login.trim().length >= 3 && password.length >= 6) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('is_authenticated', true);
      _isAuthenticated = true;
      notifyListeners();
    }
  }

  Future<void> register(String login, String password) async {
    if (login.trim().length >= 3 && password.length >= 6) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('is_authenticated', true);
      _isAuthenticated = true;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('is_authenticated', false);
    _isAuthenticated = false;
    notifyListeners();
  }
}