import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:habit_tracker/core/constants/app_colors.dart';
import 'package:habit_tracker/data/models/habit.dart';
import 'package:habit_tracker/providers/habit_provider.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';

import 'package:habit_tracker/screens/analytics/analytics_screen.dart';
import 'package:habit_tracker/screens/achievements/achievements_screen.dart';
import 'package:habit_tracker/screens/settings/settings_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _currentIndex = 0;
  late CalendarFormat _calendarFormat;
  late DateTime _focusedDay;
  late DateTime _selectedDay;

  @override
  void initState() {
    super.initState();
    _calendarFormat = CalendarFormat.month;
    _focusedDay = DateTime.now();
    _selectedDay = DateTime.now();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<HabitProvider>().loadAll();
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> _screens = [
      DashboardHome(
        calendarFormat: _calendarFormat,
        focusedDay: _focusedDay,
        selectedDay: _selectedDay,
        onDaySelected: (selectedDay, focusedDay) {
          setState(() {
            _selectedDay = selectedDay;
            _focusedDay = focusedDay;
          });
        },
        onFormatChanged: (format) {
          setState(() {
            _calendarFormat = format;
          });
        },
      ),
      const AnalyticsScreen(),
      const AchievementsScreen(),
      const SettingsScreen(),
    ];

    return Scaffold(
      // 🔴 УБРАН AppBar — нет стрелки, нет наложения
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Главная'),
          BottomNavigationBarItem(icon: Icon(Icons.show_chart), label: 'Статистика'),
          BottomNavigationBarItem(icon: Icon(Icons.star), label: 'Достижения'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Настройки'),
        ],
        selectedItemColor: AppColors.lightAccent,
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
      ),
    );
  }
}

class DashboardHome extends StatelessWidget {
  final CalendarFormat calendarFormat;
  final DateTime focusedDay;
  final DateTime selectedDay;
  final Function(DateTime, DateTime) onDaySelected;
  final Function(CalendarFormat) onFormatChanged;

  const DashboardHome({
    super.key,
    required this.calendarFormat,
    required this.focusedDay,
    required this.selectedDay,
    required this.onDaySelected,
    required this.onFormatChanged,
  });

  @override
  Widget build(BuildContext context) {
    final habitProvider = context.watch<HabitProvider>();
    final todayHabits = habitProvider.habits;
    final completedCount = todayHabits.where((h) => h.completedToday).length;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Кнопки переключения формата
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton.icon(
              onPressed: () => onFormatChanged(CalendarFormat.week),
              icon: const Icon(Icons.calendar_today),
              label: const Text('Неделя'),
              style: ElevatedButton.styleFrom(
                backgroundColor: calendarFormat == CalendarFormat.week ? AppColors.lightAccent : null,
                foregroundColor: calendarFormat == CalendarFormat.week ? Colors.white : null,
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton.icon(
              onPressed: () => onFormatChanged(CalendarFormat.twoWeeks),
              icon: const Icon(Icons.calendar_view_month),
              label: const Text('2 недели'),
              style: ElevatedButton.styleFrom(
                backgroundColor: calendarFormat == CalendarFormat.twoWeeks ? AppColors.lightAccent : null,
                foregroundColor: calendarFormat == CalendarFormat.twoWeeks ? Colors.white : null,
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton.icon(
              onPressed: () => onFormatChanged(CalendarFormat.month),
              icon: const Icon(Icons.calendar_month),
              label: const Text('Месяц'),
              style: ElevatedButton.styleFrom(
                backgroundColor: calendarFormat == CalendarFormat.month ? AppColors.lightAccent : null,
                foregroundColor: calendarFormat == CalendarFormat.month ? Colors.white : null,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),

        // Календарь
        Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(16),
          ),
          child: TableCalendar(
            firstDay: DateTime.utc(2020, 1, 1),
            lastDay: DateTime.utc(2030, 12, 31),
            focusedDay: focusedDay,
            selectedDayPredicate: (day) => isSameDay(selectedDay, day),
            onDaySelected: onDaySelected,
            calendarFormat: calendarFormat,
            locale: 'ru_RU',
            headerStyle: HeaderStyle(
              titleCentered: true,
              formatButtonVisible: false,
              titleTextStyle: Theme.of(context).textTheme.headlineMedium!.copyWith(fontWeight: FontWeight.bold),
            ),
            daysOfWeekStyle: DaysOfWeekStyle(
              weekdayStyle: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).brightness == Brightness.dark
                    ? AppColors.darkPrimaryText
                    : AppColors.lightPrimaryText,
              ),
            ),
            calendarStyle: CalendarStyle(
              todayDecoration: BoxDecoration(
                color: AppColors.lightAccent.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              selectedDecoration: BoxDecoration(
                color: AppColors.lightAccent,
                shape: BoxShape.circle,
              ),
            ),
          ),
        ),
        const SizedBox(height: 24),

        // Статистика дня
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Сегодня', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text('Выполнено $completedCount из ${todayHabits.length}'),
          ],
        ),
        const SizedBox(height: 12),

        // Список привычек
        ...todayHabits.map((habit) {
          final freq = habit.frequencyLabel;
          final goal = habit.goalLabel.isNotEmpty ? ' • ${habit.goalLabel}' : '';
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 6),
            child: ListTile(
              title: Text(habit.title),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (habit.description != null) Text(habit.description!, style: TextStyle(color: Theme.of(context).hintColor)),
                  Text('$freq$goal • Сложность: ${habit.difficulty}/5', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
                ],
              ),
              trailing: Checkbox(
                value: habit.completedToday,
                onChanged: (v) {
                  if (habit.id != null) {
                    context.read<HabitProvider>().toggleCompletion(habit.id!);
                  }
                },
              ),
            ),
          );
        }),

        const SizedBox(height: 24),
        Center(
          child: FloatingActionButton(
            onPressed: () async {
              final result = await Navigator.pushNamed(context, '/habit_form');
              if (result is Habit) {
                context.read<HabitProvider>().addHabit(result);
              }
            },
            backgroundColor: AppColors.lightAccent,
            child: const Icon(Icons.add, color: Colors.white),
          ),
        ),
      ],
    );
  }
}