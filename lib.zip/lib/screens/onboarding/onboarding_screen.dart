import 'package:flutter/material.dart';
import 'package:habit_tracker/core/utils/first_launch.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Добро пожаловать в HabitTracker!',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            const Text(
              'Создавайте привычки, отслеживайте прогресс и достигайте целей каждый день.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () async {
                await FirstLaunch.markLaunched();
                Navigator.pushReplacementNamed(context, '/auth');
              },
              child: const Text('Начать'),
            ),
          ],
        ),
      ),
    );
  }
}