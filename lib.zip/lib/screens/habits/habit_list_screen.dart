import 'package:flutter/material.dart';
import 'package:habit_tracker/core/constants/app_colors.dart';
import 'package:habit_tracker/data/models/habit.dart';
import 'package:habit_tracker/providers/habit_provider.dart';
import 'package:provider/provider.dart';

class HabitListScreen extends StatefulWidget {
  const HabitListScreen({super.key});

  @override
  State<HabitListScreen> createState() => _HabitListScreenState();
}

class _HabitListScreenState extends State<HabitListScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _filter = '';
  HabitStatus _statusFilter = HabitStatus.active;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<HabitProvider>();
    final filtered = provider.habits
        .where((h) =>
            (_statusFilter == HabitStatus.active || h.status == _statusFilter) &&
            h.title.toLowerCase().contains(_filter.toLowerCase()))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Мои привычки'),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => showSearch(context: context, delegate: HabitSearchDelegate(provider.habits)),
          ),
        ],
      ),
      body: Column(
        children: [
          // Фильтр по статусу
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildFilterChip(context, 'Активные', HabitStatus.active),
              _buildFilterChip(context, 'Завершённые', HabitStatus.completed),
              _buildFilterChip(context, 'Пауза', HabitStatus.paused),
            ],
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filtered.length,
              itemBuilder: (context, index) {
                final habit = filtered[index];
                return Dismissible(
                  key: Key(habit.id.toString()),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    child: const Icon(Icons.delete, color: Colors.white),
                  ),
                  onDismissed: (_) {
                    provider.deleteHabit(habit.id!);
                  },
                  child: Card(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: ListTile(
                      title: Text(habit.title),
                      subtitle: Text(habit.description ?? ''),
                      trailing: Icon(
                        habit.isBinary ? Icons.toggle_on : Icons.data_usage,
                        color: AppColors.lightAccent,
                      ),
                      onTap: () {
                        Navigator.pushNamed(context, '/habit_details', arguments: habit);
                      },
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, '/habit_form'),
        backgroundColor: AppColors.lightAccent,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  Widget _buildFilterChip(BuildContext context, String label, HabitStatus status) {
    final isActive = _statusFilter == status;
    return FilterChip(
      label: Text(label),
      selected: isActive,
      onSelected: (v) {
        setState(() {
          _statusFilter = status;
        });
      },
      selectedColor: AppColors.lightAccent.withOpacity(0.3),
      backgroundColor: Theme.of(context).cardColor,
    );
  }
}

class HabitSearchDelegate extends SearchDelegate {
  final List<Habit> allHabits;

  HabitSearchDelegate(this.allHabits);

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () => query = '',
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () => close(context, null),
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    final results = allHabits
        .where((h) => h.title.toLowerCase().contains(query.toLowerCase()))
        .toList();

    return ListView.builder(
      itemCount: results.length,
      itemBuilder: (context, index) {
        final habit = results[index];
        return ListTile(
          title: Text(habit.title),
          onTap: () {
            close(context, habit);
          },
        );
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return buildResults(context);
  }
}