import 'package:flutter/material.dart';
import 'package:habit_tracker/data/models/habit.dart';
import 'package:habit_tracker/providers/habit_provider.dart';
import 'package:provider/provider.dart';

class HabitDetailsScreen extends StatelessWidget {
  final Habit habit;

  const HabitDetailsScreen({super.key, required this.habit});

  @override
  Widget build(BuildContext context) {
    final habitProvider = context.watch<HabitProvider>();
    final completedCount = habitProvider.habits.where((h) => h.completedToday).length;
    final totalCount = habitProvider.habits.length;
    final rate = totalCount > 0 ? (completedCount / totalCount * 100).toStringAsFixed(1) : '0.0';

    return Scaffold(
      appBar: AppBar(title: Text(habit.title)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Статистика', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('Выполнено сегодня: $completedCount из $totalCount'),
                  Text('Процент выполнения: $rate%'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () {
              if (habit.id != null) {
                habitProvider.toggleCompletion(habit.id!);
              }
            },
            icon: const Icon(Icons.check),
            label: const Text('Отметить как выполнено'),
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: () {
              // Просто закрываем экран
              Navigator.pop(context);
            },
            icon: const Icon(Icons.close),
            label: const Text('Закрыть'),
          ),
        ],
      ),
    );
  }
}