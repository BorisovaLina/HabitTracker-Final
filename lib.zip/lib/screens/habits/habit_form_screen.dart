import 'package:flutter/material.dart';
import 'package:habit_tracker/data/models/habit.dart';

class HabitFormScreen extends StatefulWidget {
  const HabitFormScreen({super.key});

  @override
  State<HabitFormScreen> createState() => _HabitFormScreenState();
}

class _HabitFormScreenState extends State<HabitFormScreen> {
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _goalController = TextEditingController();
  final _unitController = TextEditingController();

  FrequencyType _frequency = FrequencyType.daily;
  List<int> _selectedDays = [];
  int _difficulty = 1;

  final List<String> _weekdays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Новая привычка')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(controller: _titleController, decoration: const InputDecoration(labelText: 'Название *')),
            const SizedBox(height: 12),
            TextField(controller: _descriptionController, decoration: const InputDecoration(labelText: 'Описание (опц.)')),
            
            const SizedBox(height: 16),
            Text('Частота', style: Theme.of(context).textTheme.titleMedium),
            DropdownButtonFormField<FrequencyType>(
              value: _frequency,
              items: FrequencyType.values.map((e) {
                final label = e == FrequencyType.daily ? 'Ежедневно' :
                    e == FrequencyType.weekdays ? 'Будни' :
                    e == FrequencyType.weekends ? 'Выходные' : 'Конкретные дни';
                return DropdownMenuItem(value: e, child: Text(label));
              }).toList(),
              onChanged: (v) {
                if (v != null) {
                  setState(() {
                    _frequency = v;
                    if (v != FrequencyType.custom) _selectedDays.clear();
                  });
                }
              },
            ),
            
            if (_frequency == FrequencyType.custom) ...[
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _weekdays.map((day) {
                  final idx = _weekdays.indexOf(day);
                  final isSelected = _selectedDays.contains(idx);
                  return ChoiceChip(
                    label: Text(day, style: const TextStyle(fontWeight: FontWeight.bold)),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() {
                        if (selected) {
                          _selectedDays.add(idx);
                        } else {
                          _selectedDays.remove(idx);
                        }
                      });
                    },
                    backgroundColor: Theme.of(context).cardColor,
                    selectedColor: const Color(0xFFE96B7D).withOpacity(0.3),
                  );
                }).toList(),
              ),
            ],

            const SizedBox(height: 16),
            Text('Цель', style: Theme.of(context).textTheme.titleMedium),
            Row(
              children: [
                Expanded(child: TextField(controller: _goalController, decoration: const InputDecoration(labelText: 'Значение'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: _unitController, decoration: const InputDecoration(labelText: 'Единица'))),
              ],
            ),

            const SizedBox(height: 16),
            Text('Сложность', style: Theme.of(context).textTheme.titleMedium),
            Slider(
              value: _difficulty.toDouble(),
              min: 1,
              max: 5,
              divisions: 4,
              label: '$_difficulty',
              onChanged: (v) => setState(() => _difficulty = v.round()),
            ),

            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                final habit = Habit(
                  title: _titleController.text.trim(),
                  description: _descriptionController.text.trim().isEmpty ? null : _descriptionController.text.trim(),
                  frequencyType: _frequency,
                  customDays: _selectedDays,
                  isBinary: _goalController.text.isEmpty,
                  goalValue: _goalController.text.isEmpty ? null : _goalController.text,
                  unit: _unitController.text.isEmpty ? null : _unitController.text,
                  difficulty: _difficulty,
                );
                Navigator.pop(context, habit);
              },
              child: const Text('Создать'),
            ),
          ],
        ),
      ),
    );
  }
}