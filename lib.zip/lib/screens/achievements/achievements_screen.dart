import 'package:flutter/material.dart';
import 'package:habit_tracker/core/constants/app_colors.dart';
import 'package:habit_tracker/providers/habit_provider.dart';
import 'package:provider/provider.dart';

class AchievementsScreen extends StatelessWidget {
  const AchievementsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final habits = context.watch<HabitProvider>().habits;
    final completedToday = habits.where((h) => h.completedToday).length;
    final totalHabits = habits.length;

    final achievements = [
      _makeAchievement('Первая привычка', 'Создайте первую привычку', totalHabits >= 1, Icons.star, Colors.amber),
      _makeAchievement('5 привычек', 'Имеете 5 привычек', totalHabits >= 5, Icons.view_comfy, Colors.green),
      _makeAchievement('10 привычек', 'Имеете 10 привычек', totalHabits >= 10, Icons.checklist, Colors.blue),
      _makeAchievement('25 привычек', 'Имеете 25 привычек', totalHabits >= 25, Icons.auto_awesome, Colors.purple),
      _makeAchievement('50 привычек', 'Имеете 50 привычек', totalHabits >= 50, Icons.emoji_events, Colors.orange), // ✅ trophy → emoji_events
      _makeAchievement('100 привычек', 'Имеете 100 привычек', totalHabits >= 100, Icons.military_tech, Colors.red), // ✅ crown → military_tech
      _makeAchievement('Все за день', 'Выполните все привычки сегодня', completedToday == totalHabits && totalHabits > 0, Icons.flash_on, Colors.teal),
    ];

    final unlockedCount = achievements.where((a) => a.unlocked).length;

    return Scaffold(
      appBar: AppBar(title: const Text('Достижения')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Разблокировано: $unlockedCount из ${achievements.length}'),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: unlockedCount / achievements.length,
                    backgroundColor: Theme.of(context).brightness == Brightness.dark
                        ? AppColors.darkHeatmapInactive
                        : AppColors.lightHeatmapInactive,
                    color: AppColors.lightAccent,
                    minHeight: 8,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          ...achievements.map((a) {
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 6),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: a.unlocked ? a.color.withOpacity(0.3) : Colors.grey[200],
                  child: Icon(a.icon, color: a.unlocked ? a.color : Colors.grey),
                ),
                title: Text(a.title, style: TextStyle(fontWeight: a.unlocked ? FontWeight.bold : null)),
                subtitle: Text(a.description),
                trailing: a.unlocked
                    ? const Icon(Icons.check_circle, color: Colors.green)
                    : const Icon(Icons.lock, color: Colors.grey),
              ),
            );
          }),
        ],
      ),
    );
  }

  AchievementData _makeAchievement(String title, String desc, bool unlocked, IconData icon, Color color) {
    return AchievementData(title, desc, unlocked, icon, color);
  }
}

class AchievementData {
  final String title;
  final String description;
  final bool unlocked;
  final IconData icon;
  final Color color;

  AchievementData(this.title, this.description, this.unlocked, this.icon, this.color);
}