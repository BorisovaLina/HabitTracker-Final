import 'package:flutter/material.dart';
import 'package:habit_tracker/core/constants/app_colors.dart';

class RemindersScreen extends StatefulWidget {
  const RemindersScreen({super.key});

  @override
  State<RemindersScreen> createState() => _RemindersScreenState();
}

class _RemindersScreenState extends State<RemindersScreen> {
  bool _notificationsEnabled = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Напоминания'),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            title: const Text('Включить уведомления'),
            value: _notificationsEnabled,
            onChanged: (v) => setState(() => _notificationsEnabled = v),
            activeColor: AppColors.lightAccent,
          ),

          const SizedBox(height: 16),

          Text('Активные напоминания', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),

          _buildReminderItem('Пить воду', '09:00', ['Пн', 'Вт', 'Ср', 'Чт', 'Пт']),
          _buildReminderItem('Медитация', '20:00', ['Ежедневно']),

          const SizedBox(height: 24),

          Center(
            child: ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Тестовое уведомление отправлено!')),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.lightAccent,
              ),
              child: const Text('Отправить тестовое уведомление'),
            ),
          ),

          const SizedBox(height: 16),

          ListTile(
            title: const Text('Звук уведомления'),
            subtitle: const Text('Стандартный'),
            trailing: const Icon(Icons.volume_up),
          ),
          ListTile(
            title: const Text('Вибрация'),
            subtitle: const Text('Включена'),
            trailing: Switch(
              value: true,
              activeColor: AppColors.lightAccent,
              onChanged: (_) {}, // ← ОБЯЗАТЕЛЬНО для Switch
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReminderItem(String title, String time, List<String> days) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        title: Text(title),
        subtitle: Text('$time • ${days.join(', ')}'),
        trailing: Switch(
          value: true,
          onChanged: (_) {}, // ← ОБЯЗАТЕЛЬНО
          activeColor: AppColors.lightAccent,
        ),
      ),
    );
  }
}