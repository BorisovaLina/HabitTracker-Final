import 'package:flutter/material.dart';
import 'package:habit_tracker/providers/habit_provider.dart';
import 'package:provider/provider.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final habits = context.watch<HabitProvider>().habits;
    final completedToday = habits.where((h) => h.completedToday).length;
    final totalHabits = habits.length;
    final avgDifficulty = totalHabits > 0
        ? (habits.fold(0, (sum, h) => sum + h.difficulty) / totalHabits).toStringAsFixed(1)
        : '0.0';

    return Scaffold(
      appBar: AppBar(title: const Text('Статистика')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildStatCard('Всего привычек', '$totalHabits'),
          _buildStatCard('Выполнено сегодня', '$completedToday'),
          _buildStatCard('Средняя сложность', '$avgDifficulty / 5'),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(value, style: const TextStyle(fontSize: 18)),
      ),
    );
  }
}