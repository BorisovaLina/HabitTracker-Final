import 'package:flutter/material.dart';
import 'package:habit_tracker/core/constants/app_colors.dart';
import 'package:habit_tracker/data/models/category.dart';
import 'package:habit_tracker/providers/category_provider.dart';
import 'package:provider/provider.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  Color _selectedColor = Colors.blue;

  @override
  Widget build(BuildContext context) {
    final categoryProvider = context.watch<CategoryProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Категории'),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Создать новую категорию', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 16),
            Form(
              key: _formKey,
              child: Row(
                children: [
                  CircleAvatar(
                    backgroundColor: _selectedColor,
                    radius: 16,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _nameController,
                      decoration: const InputDecoration(labelText: 'Название'),
                      validator: (v) => v!.trim().isEmpty ? 'Введите название' : null,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.palette),
                    onPressed: () => _pickColor(context),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _addCategory,
              child: const Text('Добавить'),
            ),
            const SizedBox(height: 24),
            Text('Ваши категории', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: categoryProvider.categories.length,
                itemBuilder: (context, index) {
                  final cat = categoryProvider.categories[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: cat.color,
                        radius: 16,
                      ),
                      title: Text(cat.name),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          categoryProvider.deleteCategory(cat.id!);
                        },
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _pickColor(BuildContext context) async {
    final color = await showDialog<Color>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Выберите цвет'),
        content: SingleChildScrollView(
          child: Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              for (final color in [
                Colors.green,
                Colors.blue,
                Colors.orange,
                Colors.purple,
                Colors.red,
                Colors.teal,
                Colors.pink,
                Colors.brown,
              ])
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context, color);
                  },
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.grey),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
    if (color != null) {
      setState(() => _selectedColor = color);
    }
  }

  void _addCategory() {
    if (_formKey.currentState!.validate()) {
      final name = _nameController.text.trim();
      final newCategory = Category(name: name, color: _selectedColor);
      context.read<CategoryProvider>().addCategory(newCategory);
      _nameController.clear();
      setState(() => _selectedColor = Colors.blue);
    }
  }
}