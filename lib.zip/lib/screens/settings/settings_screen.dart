import 'dart:io';
import 'package:flutter/material.dart';
import 'package:habit_tracker/core/constants/app_colors.dart';
import 'package:habit_tracker/providers/auth_provider.dart';
import 'package:habit_tracker/providers/theme_provider.dart';
import 'package:habit_tracker/screens/auth/auth_screen.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _exportDatabase(BuildContext context) async {
    try {
      final appDir = await getApplicationDocumentsDirectory();
      final dbPath = '${appDir.path}/habit_tracker.db';
      final file = File(dbPath);
      if (await file.exists()) {
        await Share.shareXFiles([XFile(dbPath)], text: 'Мои данные HabitTracker');
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('База данных пуста')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка экспорта: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Настройки')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSectionTitle('Внешний вид'),
          SwitchListTile(
            title: const Text('Тёмная тема'),
            value: themeProvider.themeMode == ThemeMode.dark,
            onChanged: (v) => themeProvider.toggleTheme(),
          ),

          _buildSectionTitle('Язык'),
          ListTile(
            title: const Text('Язык интерфейса'),
            subtitle: const Text('Русский'),
            enabled: false,
          ),

          _buildSectionTitle('Данные'),
          ListTile(
            title: const Text('Экспорт базы данных'),
            subtitle: const Text('Сохранить привычки в файл'),
            onTap: () => _exportDatabase(context),
          ),

          _buildSectionTitle('О приложении'),
          ListTile(
            title: const Text('Версия'),
            subtitle: const Text('1.0.0'),
            enabled: false,
          ),

          // 🔑 Выход из аккаунта
          _buildSectionTitle('Аккаунт'),
          ListTile(
            title: const Text('Выйти из аккаунта'),
            subtitle: const Text('Завершить текущий сеанс'),
            textColor: Colors.red,
            iconColor: Colors.red,
            onTap: () async {
              final confirmed = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Подтверждение выхода'),
                  content: const Text('Вы уверены, что хотите выйти из аккаунта?'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')),
                    TextButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('Выйти', style: TextStyle(color: Colors.red)),
                    ),
                  ],
                ),
              );

              if (confirmed == true) {
                final authProvider = context.read<AuthProvider>();
                await authProvider.logout();
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => AuthScreen()),
                  (route) => false,
                );
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Text(
        title,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    );
  }
}