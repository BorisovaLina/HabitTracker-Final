import 'package:flutter/material.dart';
import 'app_colors.dart';

// Предполагается, что шрифт Inter подключён через pubspec.yaml
const String fontFamily = 'Inter';

class AppTextStyles {
  // === СВЕТЛАЯ ТЕМА ===
  static TextStyle get lightHeadline => TextStyle(
        fontFamily: fontFamily,
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: AppColors.lightPrimaryText,
      );

  static TextStyle get lightBody => TextStyle(
        fontFamily: fontFamily,
        fontSize: 16,
        color: AppColors.lightSecondaryText,
      );

  static TextStyle get lightCaption => TextStyle(
        fontFamily: fontFamily,
        fontSize: 14,
        color: AppColors.lightTertiaryText,
      );

  static TextStyle get lightButton => TextStyle(
        fontFamily: fontFamily,
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: AppColors.white,
      );

  // === ТЁМНАЯ ТЕМА ===
  static TextStyle get darkHeadline => TextStyle(
        fontFamily: fontFamily,
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: AppColors.darkPrimaryText,
      );

  static TextStyle get darkBody => TextStyle(
        fontFamily: fontFamily,
        fontSize: 16,
        color: AppColors.darkSecondaryText,
      );

  static TextStyle get darkCaption => TextStyle(
        fontFamily: fontFamily,
        fontSize: 14,
        color: AppColors.darkTertiaryText,
      );

  static TextStyle get darkButton => TextStyle(
        fontFamily: fontFamily,
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: AppColors.darkPrimaryText, // В тёмной теме кнопки с тёмным текстом на розовом фоне
      );
}