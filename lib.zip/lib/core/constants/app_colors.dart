import 'package:flutter/material.dart';

class AppColors {
  // === СВЕТЛАЯ ТЕМА ===
  static const Color lightBackground = Color(0xFFFFFFFF); // #FFFFFF
  static const Color lightCardBackground = Color(0xFFFAFAFA); // #FAFAFA
  static const Color lightAccent = Color(0xFFE96B7D); // #E96B7D
  static const Color lightSecondary = Color(0xFFFCE8EB); // #FCE8EB
  static const Color lightPrimaryText = Color(0xFF2D2D2D); // #2D2D2D
  static const Color lightSecondaryText = Color(0xFF4A4A4A); // #4A4A4A
  static const Color lightTertiaryText = Color(0xFF6A6A6A); // Исправлено: было #6A6A4A → скорее всего опечатка
  static const Color lightDivider = Color(0xFFD0D0D0); // #D0D0D0
  static const Color lightSuccess = Color(0xFF4CAF50); // #4CAF50
  static const Color lightError = Color(0xFFFF6B6B); // #FF6B6B

  // Heatmap (light)
  static const Color lightHeatmapInactive = Color(0xFFF0F0F0);
  static const Color lightHeatmapLow = Color(0xFFFFE8EC);
  static const Color lightHeatmapMedium = Color(0xFFFFB8C6);
  static const Color lightHeatmapHigh = Color(0xFFE96B7D);

  // === ТЁМНАЯ ТЕМА ===
  static const Color darkBackground = Color(0xFF0F1714); // #0F1714
  static const Color darkCardBackground = Color(0xFF141E1A); // #141E1A
  static const Color darkAccent = Color(0xFFFF8CA4); // #FF8CA4
  static const Color darkSecondary = Color(0xFF2A1B1F); // #2A1B1F (тёмно-бордовый)
  static const Color darkPrimaryText = Color(0xFFE8E6E3); // #E8E6E3 (тёплый бежевый)
  static const Color darkSecondaryText = Color(0xFFC5C3C0); // #C5C3C0
  static const Color darkTertiaryText = Color(0xFFA8A6A3); // #A8A6A3
  static const Color darkDivider = Color(0xFF33A440); // #33A440 (тёмно-зелёный с оттенком)

  static const Color darkSuccess = Color(0xFF2E7D32); // #2E7D32
  static const Color darkError = Color(0xFFD32F2F); // #D32F2F

  // Heatmap (dark)
  static const Color darkHeatmapInactive = Color(0xFF232D28);
  static const Color darkHeatmapLow = Color(0xFF1A2821);
  static const Color darkHeatmapMedium = Color(0xFF284032);
  static const Color darkHeatmapHigh = Color(0xFFFF8CA4);

  // Общие (независимо от темы)
  static const Color white = Colors.white;
  static const Color black = Colors.black;
}