import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_text_styles.dart';

class AppTheme {
  static final ThemeData lightTheme = ThemeData(
    brightness: Brightness.light,
    primaryColor: AppColors.lightAccent,
    scaffoldBackgroundColor: AppColors.lightBackground,
    cardColor: AppColors.lightCardBackground,
    dividerColor: AppColors.lightDivider,
    textTheme: TextTheme(
      headlineMedium: AppTextStyles.lightHeadline,
      bodyMedium: AppTextStyles.lightBody,
      labelSmall: AppTextStyles.lightCaption,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.lightAccent,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 24),
        elevation: 0,
        textStyle: AppTextStyles.lightButton,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: AppColors.lightDivider)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: AppColors.lightDivider)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: AppColors.lightAccent, width: 2)),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(color: AppColors.lightAccent),
    useMaterial3: true,
    // Замена toggleableActiveColor
    colorScheme: ColorScheme.light(
      primary: AppColors.lightAccent,
      secondary: AppColors.lightSecondary,
      surface: AppColors.lightCardBackground,
      background: AppColors.lightBackground,
      error: AppColors.lightError,
      onPrimary: Colors.white,
      onSecondary: AppColors.lightPrimaryText,
      onSurface: AppColors.lightPrimaryText,
      onBackground: AppColors.lightPrimaryText,
      onError: Colors.white,
    ),
  );

  static final ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: AppColors.darkAccent,
    scaffoldBackgroundColor: AppColors.darkBackground,
    cardColor: AppColors.darkCardBackground,
    dividerColor: AppColors.darkDivider,
    textTheme: TextTheme(
      headlineMedium: AppTextStyles.darkHeadline,
      bodyMedium: AppTextStyles.darkBody,
      labelSmall: AppTextStyles.darkCaption,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.darkAccent,
        foregroundColor: AppColors.darkPrimaryText,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 24),
        elevation: 0,
        textStyle: AppTextStyles.darkButton,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: AppColors.darkDivider)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: AppColors.darkDivider)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: AppColors.darkAccent, width: 2)),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(color: AppColors.darkAccent),
    useMaterial3: true,
    colorScheme: ColorScheme.dark(
      primary: AppColors.darkAccent,
      secondary: AppColors.darkSecondary,
      surface: AppColors.darkCardBackground,
      background: AppColors.darkBackground,
      error: AppColors.darkError,
      onPrimary: AppColors.darkPrimaryText,
      onSecondary: AppColors.darkPrimaryText,
      onSurface: AppColors.darkPrimaryText,
      onBackground: AppColors.darkPrimaryText,
      onError: Colors.white,
    ),
  );
}