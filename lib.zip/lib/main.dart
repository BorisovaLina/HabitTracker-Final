import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:habit_tracker/core/theme/app_theme.dart';
import 'package:habit_tracker/data/models/habit.dart';
import 'package:habit_tracker/providers/auth_provider.dart';
import 'package:habit_tracker/providers/category_provider.dart';
import 'package:habit_tracker/providers/habit_provider.dart';
import 'package:habit_tracker/providers/theme_provider.dart';
import 'package:provider/provider.dart';

// Экраны
import 'screens/analytics/analytics_screen.dart';
import 'screens/achievements/achievements_screen.dart';
import 'screens/auth/auth_screen.dart';
import 'screens/categories/categories_screen.dart';
import 'screens/dashboard/dashboard_screen.dart';
import 'screens/habits/habit_details_screen.dart';
import 'screens/habits/habit_form_screen.dart';
import 'screens/login/login_screen.dart';
import 'screens/onboarding/onboarding_screen.dart';
import 'screens/settings/settings_screen.dart';
import 'screens/splash/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Инициализация локали для intl (обязательно для Web и Android)
  await initializeDateFormatting('ru', null);
  Intl.defaultLocale = 'ru_RU'; // ← гарантирует русскую локаль везде

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => HabitProvider()),
        ChangeNotifierProvider(create: (_) => CategoryProvider()),
      ],
      child: const HabitTrackerApp(),
    ),
  );
}

class HabitTrackerApp extends StatelessWidget {
  const HabitTrackerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HabitTracker',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: context.watch<ThemeProvider>().themeMode,
      initialRoute: '/splash',
      routes: {
        '/splash': (context) => const SplashScreen(),
        '/onboarding': (context) => const OnboardingScreen(),
        '/auth': (context) => const AuthScreen(),
        '/login': (context) => const LoginScreen(isLogin: true),
        '/register': (context) => const LoginScreen(isLogin: false),
        '/dashboard': (context) => const DashboardScreen(),
        '/habit_form': (context) => const HabitFormScreen(),
        '/habit_details': (context) {
          final args = ModalRoute.of(context)?.settings.arguments;
          if (args is Habit) {
            return HabitDetailsScreen(habit: args);
          }
          return const DashboardScreen();
        },
        '/categories': (context) => const CategoriesScreen(),
        '/analytics': (context) => const AnalyticsScreen(),
        '/achievements': (context) => const AchievementsScreen(),
        '/settings': (context) => const SettingsScreen(),
      },
      onUnknownRoute: (settings) {
        return MaterialPageRoute(builder: (_) => const DashboardScreen());
      },
    );
  }
}